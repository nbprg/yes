from core import logo
import os, time
def __cls__():
    os.system('clear')
    print(logo.get())
def run():
    __cls__()
    url = input('Put Login Link: ')
    if 'https' and '7D' in url:
        open('core/login_links.txt','w').write(str(url).replace(' ',''))
        __cls__()
        print('Run : \033[1;32mpython main.py ')
    else:
        __cls__()
        print('Login Url Invalid, Try again ')
        time.sleep(3)
        run()
if '__main__' == __name__:
     run()
