import requests, re, random
import urllib.parse as dec
def ch():
   colors =[
    '\033[1;32m','\033[1;31m',
    '\033[1;34m','\033[1;35m',
    '\033[0m','\033[0;34m',
    '\033[1;36m','\033[39m',
    ]
   return random.choice(colors)
def de(err_url):
    prox = dec.unquote(err_url)
    proy = dec.unquote(prox)
    proz = proy.split('user=')[1].split('&tg')[0]
    json = f"user={proz}"
    headers = {'authority': 'api-backend.yescoin.gold', 'accept': 'application/json, text/plain, */*', 'user-agent': 'Mozilla/5.0 (X11; Linux aarch64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.114 Safari/537.36', 'content-type': 'application/json', 'origin': 'https://www.yescoin.gold', 'sec-fetch-site': 'same-site', 'sec-fetch-mode': 'cors', 'sec-fetch-dest': 'empty', 'referer': 'https://www.yescoin.gold/', 'accept-language': 'en-US,en;q=0.9'}
    json_data = {
    'code': json
    }
    response = requests.post('https://api-backend.yescoin.gold/user/login', headers=headers, json=json_data).json()
    name = re.search('first_name":"(.*?)","',str(proz)).group(1)
    if 'token' in str(response):
        print(f'\r{ch()}Login Success: {name}')
    return {'token': response['data']['token'],'name': name}
