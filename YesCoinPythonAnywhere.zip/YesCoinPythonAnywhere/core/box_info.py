import requests
def info(token=None):
    headers = {'Host': 'api-backend.yescoin.gold','sec-ch-ua-platform': 'Android','user-agent': 'Mozilla/5.0 (Linux; Android 14; 23129RAA4G Build/UKQ1.231207.002) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.6668.100 Mobile Safari/537.36','accept': 'application/json, text/plain, */*','sec-ch-ua': 'Android','sec-ch-ua-mobile': '?1','origin': 'https://www.yescoin.gold','sec-fetch-site': 'same-site','sec-fetch-mode': 'cors','sec-fetch-dest': 'empty','referer': 'https://www.yescoin.gold/','accept-language': 'en-US,en;q=0.9','priority': 'u=1, i'}
    if token:
       headers.update({'token': token})
    response = requests.get('https://api-backend.yescoin.gold/game/getSpecialBoxInfo', headers=headers).text
    return response