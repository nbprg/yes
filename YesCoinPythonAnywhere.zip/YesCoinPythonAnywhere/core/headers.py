def get(token=None):
    headers = {
    'authority': 'api-backend.yescoin.gold',
    'accept': 'application/json, text/plain, */*',
    'user-agent': 'Mozilla/5.0 (X11; Linux aarch64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.114 Safari/537.36',
    'content-type': 'application/json',
    'origin': 'https://www.yescoin.gold',
    'sec-fetch-site': 'same-site',
    'sec-fetch-mode': 'cors',
    'sec-fetch-dest': 'empty',
    'referer': 'https://www.yescoin.gold/',
    'accept-language': 'en-US,en;q=0.9',
    }
    if token:
        headers.update({'token': token})
    return headers