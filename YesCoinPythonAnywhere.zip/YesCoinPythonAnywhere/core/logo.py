content = """\033[0m
Developer = "Saifur Rahman Siam"
Facebook  = "facebook.com/shishir.ahmed.z"
Telegram  = "https://t.me/TataCuto"
\033[0m-----------------------------------------"""
br = "\033[0m-----------------------------------------"
def get():return(content)
def __br__():return(br)
